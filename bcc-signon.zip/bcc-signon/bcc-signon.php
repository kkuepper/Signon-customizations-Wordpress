<?php
/*
Plugin Name: BCC Signon
Description: BCC signon system (support: it@bcc.no).
Version: 1.0.0
Author: BCC
*/

require plugin_dir_path( dirname( __FILE__) ) . 'openid-connect-bcc-customizations/bcc-signon.php';
require plugin_dir_path( dirname( __FILE__) ) . 'openid-connect-generic-client/openid-connect-generic.php';
?>